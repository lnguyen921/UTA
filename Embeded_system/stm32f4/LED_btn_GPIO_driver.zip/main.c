/* 
 This lab is using GPIO driver to set GPIO pin number, mode, speed, type, and control. 
 
 Operation: 
 When a button in port A is pressed, LED that correspond to pin 13 is enabled.
 LED the correspond to pin 14 will be disabled.
 
*/
#include <stdint.h>
#include "stm32fxx.h"

#define BTN_PRESSED HIGH
#define LOW 0
#define HIGH 1
#define DISABLE 0
#define ENABLE 1

void delay(void)
{
	for(uint32_t i = 0 ; i < 500000 ; i++);
}


int main(void)
{
	GPIO_Handle_t GpioLed;
	GPIO_Handle_t GpioLed_2;

	GpioLed.pGPIOx = GPIOD); 
	GpioLed_2.pGPIOx = GPIOD);

	GpioLed_2.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_13; 			
	GpioLed_2.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	GpioLed_2.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_VERYHIGH;
	GpioLed_2.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioLed_2.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;

	GpioLed.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_14; 
	GpioLed.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	GpioLed.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_VERYHIGH;
	GpioLed.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioLed.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;

	GPIO_Handle_t GpioBtn;

	GpioBtn.pGPIOx = GPIOA); 
	GpioBtn.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_0;
	GpioBtn.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_IN;
	GpioBtn.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_VERYHIGH;
	GpioBtn.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;


	GPIO_PeriClockControl(GPIOD), ENABLE);
	GPIO_PeriClockControl(GPIOA), ENABLE);


	GPIO_Init(&GpioLed);
	GPIO_Init(&GpioBtn);
	GPIO_Init(&GpioLed_2);


	while(1)
	{

		if(GPIO_ReadFromInputPin(GPIOA), GPIO_PIN_NO_0) == BTN_PRESSED)
		{

			GPIO_WriteToOutputPin(GPIOD), GPIO_PIN_NO_14, DISABLE);

			GPIO_WriteToOutputPin(GPIOD), GPIO_PIN_NO_13, ENABLE);

			delay();

		}
		else {
			GPIO_WriteToOutputPin(GPIOD), GPIO_PIN_NO_14, ENABLE);

			GPIO_WriteToOutputPin(GPIOD), GPIO_PIN_NO_13, DISABLE);

			delay();
		}

	}

	return 0;
}

/* Below is the pseudocode for the code above.

Define BTN_PRESSED as HIGH
Define LOW as 0
Define HIGH as 1
Define DISABLE as 0
Define ENABLE as 1

Function delay():
    For i from 0 to 500000:
																				// Delay loop

Function main():
    Initialize GpioLed as GPIO_Handle_t
    Initialize GpioLed_2 as GPIO_Handle_t
    Initialize GpioBtn as GPIO_Handle_t

    Set GpioLed.pGPIOx to GPIOD 											    // Specify the port for GpioLed
    Set GpioLed_2.pGPIOx to GPIOD 												// Specify the port for GpioLed_2

    Set GpioLed_2.GPIO_PinConfig.GPIO_PinNumber to GPIO_PIN_NO_13 				// Set PD13 for orange LED
    Set GpioLed_2.GPIO_PinConfig.GPIO_PinMode to GPIO_MODE_OUT
    Set GpioLed_2.GPIO_PinConfig.GPIO_PinSpeed to GPIO_SPEED_VERYHIGH
    Set GpioLed_2.GPIO_PinConfig.GPIO_PinOPType to GPIO_OP_TYPE_PP
    Set GpioLed_2.GPIO_PinConfig.GPIO_PinPuPdControl to GPIO_NO_PUPD

    Set GpioLed.GPIO_PinConfig.GPIO_PinNumber to GPIO_PIN_NO_14 				// Set PD14 for red LED
    Set GpioLed.GPIO_PinConfig.GPIO_PinMode to GPIO_MODE_OUT
    Set GpioLed.GPIO_PinConfig.GPIO_PinSpeed to GPIO_SPEED_VERYHIGH
    Set GpioLed.GPIO_PinConfig.GPIO_PinOPType to GPIO_OP_TYPE_PP
    Set GpioLed.GPIO_PinConfig.GPIO_PinPuPdControl to GPIO_NO_PUPD

    Set GpioBtn.pGPIOx to GPIOA 												// Set port A for button
    Set GpioBtn.GPIO_PinConfig.GPIO_PinNumber to GPIO_PIN_NO_0
    Set GpioBtn.GPIO_PinConfig.GPIO_PinMode to GPIO_MODE_IN
    Set GpioBtn.GPIO_PinConfig.GPIO_PinSpeed to GPIO_SPEED_VERYHIGH
    Set GpioBtn.GPIO_PinConfig.GPIO_PinPuPdControl to GPIO_NO_PUPD

    Enable the peripheral clock for GPIOD and GPIOA

    Initialize GPIO pins for GpioLed, GpioLed_2, and GpioBtn

    Loop:
        If GPIO pin PA0 (Button) is pressed:
            Disable GPIO pin PD14 (Red LED)
            Enable GPIO pin PD13 (Orange LED)
            Call delay() function
        Else:
            Enable GPIO pin PD14 (Red LED)
            Disable GPIO pin PD13 (Orange LED)
            Call delay() function

    Return 0
 */